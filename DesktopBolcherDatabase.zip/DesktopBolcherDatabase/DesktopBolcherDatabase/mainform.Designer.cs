﻿namespace DesktopBolcherDatabase
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtnavn = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.txtfave = new System.Windows.Forms.TextBox();
            this.txtvagt = new System.Windows.Forms.TextBox();
            this.txtsurhed = new System.Windows.Forms.TextBox();
            this.txtstyrke = new System.Windows.Forms.TextBox();
            this.txttype = new System.Windows.Forms.TextBox();
            this.txtpris = new System.Windows.Forms.TextBox();
            this.Indset = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.update = new System.Windows.Forms.Button();
            this.slet = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtslet = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.clearslet = new System.Windows.Forms.Button();
            this.txtupdatenavn = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.søg = new System.Windows.Forms.Button();
            this.sognavn = new System.Windows.Forms.TextBox();
            this.sognulstil = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.display = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtIDupdate = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.kolonnenavn = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.lukke = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.hidegrid = new System.Windows.Forms.Button();
            this.showgrid = new System.Windows.Forms.Button();
            this.radiofave = new System.Windows.Forms.RadioButton();
            this.radiovagt = new System.Windows.Forms.RadioButton();
            this.radiopris = new System.Windows.Forms.RadioButton();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.radiotype = new System.Windows.Forms.RadioButton();
            this.radiostyrke = new System.Windows.Forms.RadioButton();
            this.radiosurhed = new System.Windows.Forms.RadioButton();
            this.radionavn = new System.Windows.Forms.RadioButton();
            this.databaseDataSet = new DesktopBolcherDatabase.databaseDataSet();
            this.bolchertabelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bolchertabelTableAdapter = new DesktopBolcherDatabase.databaseDataSetTableAdapters.bolchertabelTableAdapter();
            this.databaseDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.checktil = new System.Windows.Forms.CheckBox();
            this.checkfra = new System.Windows.Forms.CheckBox();
            this.label29 = new System.Windows.Forms.Label();
            this.sorttil = new System.Windows.Forms.CheckBox();
            this.sortfra = new System.Windows.Forms.CheckBox();
            this.label30 = new System.Windows.Forms.Label();
            this.vagtlisttil = new System.Windows.Forms.CheckBox();
            this.vagtlist = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bolchertabelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSetBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // txtnavn
            // 
            this.txtnavn.BackColor = System.Drawing.Color.White;
            this.txtnavn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnavn.Location = new System.Drawing.Point(17, 72);
            this.txtnavn.MaxLength = 250;
            this.txtnavn.Name = "txtnavn";
            this.txtnavn.Size = new System.Drawing.Size(100, 27);
            this.txtnavn.TabIndex = 0;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // txtfave
            // 
            this.txtfave.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfave.Location = new System.Drawing.Point(123, 72);
            this.txtfave.MaxLength = 250;
            this.txtfave.Name = "txtfave";
            this.txtfave.Size = new System.Drawing.Size(100, 27);
            this.txtfave.TabIndex = 2;
            // 
            // txtvagt
            // 
            this.txtvagt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtvagt.Location = new System.Drawing.Point(229, 72);
            this.txtvagt.MaxLength = 250;
            this.txtvagt.Name = "txtvagt";
            this.txtvagt.Size = new System.Drawing.Size(100, 27);
            this.txtvagt.TabIndex = 3;
            // 
            // txtsurhed
            // 
            this.txtsurhed.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsurhed.Location = new System.Drawing.Point(17, 127);
            this.txtsurhed.MaxLength = 250;
            this.txtsurhed.Name = "txtsurhed";
            this.txtsurhed.Size = new System.Drawing.Size(100, 27);
            this.txtsurhed.TabIndex = 4;
            // 
            // txtstyrke
            // 
            this.txtstyrke.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstyrke.Location = new System.Drawing.Point(123, 127);
            this.txtstyrke.MaxLength = 250;
            this.txtstyrke.Name = "txtstyrke";
            this.txtstyrke.Size = new System.Drawing.Size(100, 27);
            this.txtstyrke.TabIndex = 5;
            // 
            // txttype
            // 
            this.txttype.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttype.Location = new System.Drawing.Point(229, 127);
            this.txttype.MaxLength = 250;
            this.txttype.Name = "txttype";
            this.txttype.Size = new System.Drawing.Size(100, 27);
            this.txttype.TabIndex = 6;
            // 
            // txtpris
            // 
            this.txtpris.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpris.Location = new System.Drawing.Point(17, 180);
            this.txtpris.MaxLength = 60;
            this.txtpris.Name = "txtpris";
            this.txtpris.Size = new System.Drawing.Size(100, 27);
            this.txtpris.TabIndex = 7;
            // 
            // Indset
            // 
            this.Indset.BackColor = System.Drawing.Color.Gainsboro;
            this.Indset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Indset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Indset.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Indset.Location = new System.Drawing.Point(130, 178);
            this.Indset.Name = "Indset";
            this.Indset.Size = new System.Drawing.Size(92, 30);
            this.Indset.TabIndex = 8;
            this.Indset.Text = "Indset";
            this.Indset.UseVisualStyleBackColor = false;
            this.Indset.Click += new System.EventHandler(this.Indset_Click);
            // 
            // clear
            // 
            this.clear.BackColor = System.Drawing.Color.Gainsboro;
            this.clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clear.Location = new System.Drawing.Point(228, 178);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(100, 30);
            this.clear.TabIndex = 9;
            this.clear.Text = "Nulstil";
            this.clear.UseVisualStyleBackColor = false;
            this.clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // update
            // 
            this.update.BackColor = System.Drawing.Color.Gainsboro;
            this.update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.update.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.update.Location = new System.Drawing.Point(14, 334);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(100, 28);
            this.update.TabIndex = 10;
            this.update.Text = "Update";
            this.update.UseVisualStyleBackColor = false;
            this.update.Click += new System.EventHandler(this.Update_Click);
            // 
            // slet
            // 
            this.slet.BackColor = System.Drawing.Color.Gainsboro;
            this.slet.Cursor = System.Windows.Forms.Cursors.Hand;
            this.slet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.slet.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slet.Location = new System.Drawing.Point(126, 443);
            this.slet.Name = "slet";
            this.slet.Size = new System.Drawing.Size(92, 29);
            this.slet.TabIndex = 11;
            this.slet.Text = "Slet";
            this.slet.UseVisualStyleBackColor = false;
            this.slet.Click += new System.EventHandler(this.Slet_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.Default;
            this.dataGridView1.Location = new System.Drawing.Point(366, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(863, 819);
            this.dataGridView1.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(240, 25);
            this.label1.TabIndex = 13;
            this.label1.Text = "Opret ny Bolche table";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 16);
            this.label2.TabIndex = 14;
            this.label2.Text = "Bolche navn ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(125, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 16);
            this.label3.TabIndex = 15;
            this.label3.Text = "Bolche fave";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(232, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 16);
            this.label4.TabIndex = 16;
            this.label4.Text = "Bolche Vægt";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(14, 108);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 16);
            this.label5.TabIndex = 17;
            this.label5.Text = "Smags surhed ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(122, 108);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 16);
            this.label6.TabIndex = 18;
            this.label6.Text = "Smags styrke";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(231, 108);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 16);
            this.label7.TabIndex = 19;
            this.label7.Text = "Smags Type";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(17, 161);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(85, 16);
            this.label8.TabIndex = 20;
            this.label8.Text = "Råvarepris";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(12, 218);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(319, 13);
            this.label9.TabIndex = 21;
            this.label9.Text = "------------------------------------------------------------------------------";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(15, 384);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(145, 25);
            this.label10.TabIndex = 22;
            this.label10.Text = "Slet en table";
            // 
            // txtslet
            // 
            this.txtslet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtslet.Location = new System.Drawing.Point(17, 444);
            this.txtslet.MaxLength = 250;
            this.txtslet.Name = "txtslet";
            this.txtslet.Size = new System.Drawing.Size(100, 27);
            this.txtslet.TabIndex = 23;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(18, 421);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(68, 16);
            this.label11.TabIndex = 24;
            this.label11.Text = "Table ID";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(10, 482);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(319, 13);
            this.label12.TabIndex = 25;
            this.label12.Text = "------------------------------------------------------------------------------";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(14, 231);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(207, 25);
            this.label13.TabIndex = 26;
            this.label13.Text = "Updater table data";
            // 
            // clearslet
            // 
            this.clearslet.BackColor = System.Drawing.Color.Gainsboro;
            this.clearslet.Cursor = System.Windows.Forms.Cursors.Hand;
            this.clearslet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.clearslet.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearslet.Location = new System.Drawing.Point(227, 442);
            this.clearslet.Name = "clearslet";
            this.clearslet.Size = new System.Drawing.Size(100, 30);
            this.clearslet.TabIndex = 27;
            this.clearslet.Text = "Nulstil";
            this.clearslet.UseVisualStyleBackColor = false;
            this.clearslet.Click += new System.EventHandler(this.Clearslet_Click);
            // 
            // txtupdatenavn
            // 
            this.txtupdatenavn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtupdatenavn.Location = new System.Drawing.Point(232, 290);
            this.txtupdatenavn.MaxLength = 250;
            this.txtupdatenavn.Name = "txtupdatenavn";
            this.txtupdatenavn.Size = new System.Drawing.Size(100, 27);
            this.txtupdatenavn.TabIndex = 28;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(10, 371);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(319, 13);
            this.label14.TabIndex = 30;
            this.label14.Text = "------------------------------------------------------------------------------";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(13, 497);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(183, 25);
            this.label15.TabIndex = 31;
            this.label15.Text = "Søg i databasen";
            // 
            // søg
            // 
            this.søg.BackColor = System.Drawing.Color.Gainsboro;
            this.søg.Cursor = System.Windows.Forms.Cursors.Hand;
            this.søg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.søg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.søg.Location = new System.Drawing.Point(126, 553);
            this.søg.Name = "søg";
            this.søg.Size = new System.Drawing.Size(92, 28);
            this.søg.TabIndex = 32;
            this.søg.Text = "Søg";
            this.søg.UseVisualStyleBackColor = false;
            this.søg.Click += new System.EventHandler(this.Søg_Click);
            // 
            // sognavn
            // 
            this.sognavn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sognavn.Location = new System.Drawing.Point(16, 553);
            this.sognavn.MaxLength = 250;
            this.sognavn.Name = "sognavn";
            this.sognavn.Size = new System.Drawing.Size(100, 27);
            this.sognavn.TabIndex = 33;
            // 
            // sognulstil
            // 
            this.sognulstil.BackColor = System.Drawing.Color.Gainsboro;
            this.sognulstil.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sognulstil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sognulstil.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sognulstil.Location = new System.Drawing.Point(229, 552);
            this.sognulstil.Name = "sognulstil";
            this.sognulstil.Size = new System.Drawing.Size(100, 30);
            this.sognulstil.TabIndex = 34;
            this.sognulstil.Text = "Nulstil";
            this.sognulstil.UseVisualStyleBackColor = false;
            this.sognulstil.Click += new System.EventHandler(this.Sognulstil_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(15, 530);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(91, 16);
            this.label16.TabIndex = 35;
            this.label16.Text = "Søg i tablen";
            // 
            // display
            // 
            this.display.BackColor = System.Drawing.Color.Gainsboro;
            this.display.Cursor = System.Windows.Forms.Cursors.Hand;
            this.display.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.display.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.display.Location = new System.Drawing.Point(123, 743);
            this.display.Name = "display";
            this.display.Size = new System.Drawing.Size(204, 30);
            this.display.TabIndex = 36;
            this.display.Text = "Genindlæses Table Data";
            this.display.UseVisualStyleBackColor = false;
            this.display.Click += new System.EventHandler(this.Display_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(241, 263);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(0, 13);
            this.label17.TabIndex = 37;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(232, 271);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(55, 16);
            this.label18.TabIndex = 38;
            this.label18.Text = "Ny text";
            // 
            // txtIDupdate
            // 
            this.txtIDupdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIDupdate.Location = new System.Drawing.Point(16, 290);
            this.txtIDupdate.MaxLength = 250;
            this.txtIDupdate.Name = "txtIDupdate";
            this.txtIDupdate.Size = new System.Drawing.Size(100, 27);
            this.txtIDupdate.TabIndex = 39;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(14, 271);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(68, 16);
            this.label19.TabIndex = 40;
            this.label19.Text = "Table ID";
            // 
            // kolonnenavn
            // 
            this.kolonnenavn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kolonnenavn.Location = new System.Drawing.Point(124, 290);
            this.kolonnenavn.MaxLength = 250;
            this.kolonnenavn.Name = "kolonnenavn";
            this.kolonnenavn.Size = new System.Drawing.Size(100, 27);
            this.kolonnenavn.TabIndex = 41;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(123, 271);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(75, 16);
            this.label20.TabIndex = 42;
            this.label20.Text = "Row navn";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(13, 726);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(319, 13);
            this.label21.TabIndex = 43;
            this.label21.Text = "------------------------------------------------------------------------------";
            // 
            // lukke
            // 
            this.lukke.BackColor = System.Drawing.Color.Gainsboro;
            this.lukke.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lukke.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lukke.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lukke.Location = new System.Drawing.Point(123, 779);
            this.lukke.Name = "lukke";
            this.lukke.Size = new System.Drawing.Size(204, 30);
            this.lukke.TabIndex = 44;
            this.lukke.Text = "Afslut programmet";
            this.lukke.UseVisualStyleBackColor = false;
            this.lukke.Click += new System.EventHandler(this.Lukke_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Gainsboro;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(126, 334);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 30);
            this.button1.TabIndex = 45;
            this.button1.Text = "Nulstil";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // hidegrid
            // 
            this.hidegrid.BackColor = System.Drawing.Color.Gainsboro;
            this.hidegrid.Cursor = System.Windows.Forms.Cursors.Hand;
            this.hidegrid.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.hidegrid.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hidegrid.Location = new System.Drawing.Point(16, 742);
            this.hidegrid.Name = "hidegrid";
            this.hidegrid.Size = new System.Drawing.Size(96, 30);
            this.hidegrid.TabIndex = 46;
            this.hidegrid.Text = "Skjul table ";
            this.hidegrid.UseVisualStyleBackColor = false;
            this.hidegrid.Click += new System.EventHandler(this.Hidegrid_Click);
            // 
            // showgrid
            // 
            this.showgrid.BackColor = System.Drawing.Color.Gainsboro;
            this.showgrid.Cursor = System.Windows.Forms.Cursors.Hand;
            this.showgrid.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.showgrid.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.showgrid.Location = new System.Drawing.Point(16, 780);
            this.showgrid.Name = "showgrid";
            this.showgrid.Size = new System.Drawing.Size(97, 30);
            this.showgrid.TabIndex = 47;
            this.showgrid.Text = "Vis table ";
            this.showgrid.UseVisualStyleBackColor = false;
            this.showgrid.Click += new System.EventHandler(this.Showgrid_Click);
            // 
            // radiofave
            // 
            this.radiofave.AutoSize = true;
            this.radiofave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radiofave.Location = new System.Drawing.Point(21, 624);
            this.radiofave.Name = "radiofave";
            this.radiofave.Size = new System.Drawing.Size(83, 17);
            this.radiofave.TabIndex = 49;
            this.radiofave.Text = "Søg på fave";
            this.radiofave.UseVisualStyleBackColor = true;
            // 
            // radiovagt
            // 
            this.radiovagt.AutoSize = true;
            this.radiovagt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radiovagt.Location = new System.Drawing.Point(125, 624);
            this.radiovagt.Name = "radiovagt";
            this.radiovagt.Size = new System.Drawing.Size(87, 17);
            this.radiovagt.TabIndex = 50;
            this.radiovagt.Text = "Søg på vægt";
            this.radiovagt.UseVisualStyleBackColor = true;
            // 
            // radiopris
            // 
            this.radiopris.AutoSize = true;
            this.radiopris.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radiopris.Location = new System.Drawing.Point(231, 624);
            this.radiopris.Name = "radiopris";
            this.radiopris.Size = new System.Drawing.Size(78, 17);
            this.radiopris.TabIndex = 51;
            this.radiopris.Text = "Søg på pris";
            this.radiopris.UseVisualStyleBackColor = true;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(16, 588);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(113, 13);
            this.label22.TabIndex = 52;
            this.label22.Text = "Avanceret søgning";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(112, 626);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(9, 13);
            this.label23.TabIndex = 53;
            this.label23.Text = "|";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(214, 626);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(9, 13);
            this.label24.TabIndex = 54;
            this.label24.Text = "|";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(214, 649);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(9, 13);
            this.label25.TabIndex = 59;
            this.label25.Text = "|";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(113, 649);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(9, 13);
            this.label26.TabIndex = 58;
            this.label26.Text = "|";
            // 
            // radiotype
            // 
            this.radiotype.AutoSize = true;
            this.radiotype.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radiotype.Location = new System.Drawing.Point(231, 647);
            this.radiotype.Name = "radiotype";
            this.radiotype.Size = new System.Drawing.Size(82, 17);
            this.radiotype.TabIndex = 57;
            this.radiotype.Text = "Søg på type";
            this.radiotype.UseVisualStyleBackColor = true;
            // 
            // radiostyrke
            // 
            this.radiostyrke.AutoSize = true;
            this.radiostyrke.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radiostyrke.Location = new System.Drawing.Point(125, 647);
            this.radiostyrke.Name = "radiostyrke";
            this.radiostyrke.Size = new System.Drawing.Size(90, 17);
            this.radiostyrke.TabIndex = 56;
            this.radiostyrke.Text = "Søg på styrke";
            this.radiostyrke.UseVisualStyleBackColor = true;
            // 
            // radiosurhed
            // 
            this.radiosurhed.AutoSize = true;
            this.radiosurhed.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radiosurhed.Location = new System.Drawing.Point(21, 647);
            this.radiosurhed.Name = "radiosurhed";
            this.radiosurhed.Size = new System.Drawing.Size(94, 17);
            this.radiosurhed.TabIndex = 55;
            this.radiosurhed.Text = "Søg på surhed";
            this.radiosurhed.UseVisualStyleBackColor = true;
            // 
            // radionavn
            // 
            this.radionavn.AutoSize = true;
            this.radionavn.Checked = true;
            this.radionavn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radionavn.Location = new System.Drawing.Point(21, 603);
            this.radionavn.Name = "radionavn";
            this.radionavn.Size = new System.Drawing.Size(86, 17);
            this.radionavn.TabIndex = 60;
            this.radionavn.TabStop = true;
            this.radionavn.Text = "Søg på navn";
            this.radionavn.UseVisualStyleBackColor = true;
            // 
            // databaseDataSet
            // 
            this.databaseDataSet.DataSetName = "databaseDataSet";
            this.databaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bolchertabelBindingSource
            // 
            this.bolchertabelBindingSource.DataMember = "bolchertabel";
            this.bolchertabelBindingSource.DataSource = this.databaseDataSet;
            // 
            // bolchertabelTableAdapter
            // 
            this.bolchertabelTableAdapter.ClearBeforeFill = true;
            // 
            // databaseDataSetBindingSource
            // 
            this.databaseDataSetBindingSource.DataSource = this.databaseDataSet;
            this.databaseDataSetBindingSource.Position = 0;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(218, 495);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(0, 16);
            this.label27.TabIndex = 62;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(16, 674);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(137, 13);
            this.label28.TabIndex = 63;
            this.label28.Text = "Case sensitive søgning";
            // 
            // checktil
            // 
            this.checktil.AutoSize = true;
            this.checktil.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checktil.Location = new System.Drawing.Point(164, 674);
            this.checktil.Name = "checktil";
            this.checktil.Size = new System.Drawing.Size(37, 17);
            this.checktil.TabIndex = 65;
            this.checktil.Text = "Til";
            this.checktil.UseVisualStyleBackColor = true;
            // 
            // checkfra
            // 
            this.checkfra.AutoSize = true;
            this.checkfra.Checked = true;
            this.checkfra.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkfra.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkfra.Location = new System.Drawing.Point(207, 674);
            this.checkfra.Name = "checkfra";
            this.checkfra.Size = new System.Drawing.Size(41, 17);
            this.checkfra.TabIndex = 66;
            this.checkfra.Text = "Fra";
            this.checkfra.UseVisualStyleBackColor = true;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(15, 693);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(111, 13);
            this.label29.TabIndex = 67;
            this.label29.Text = "Sorteret alfabetisk";
            // 
            // sorttil
            // 
            this.sorttil.AutoSize = true;
            this.sorttil.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sorttil.Location = new System.Drawing.Point(164, 692);
            this.sorttil.Name = "sorttil";
            this.sorttil.Size = new System.Drawing.Size(37, 17);
            this.sorttil.TabIndex = 68;
            this.sorttil.Text = "Til";
            this.sorttil.UseVisualStyleBackColor = true;
            // 
            // sortfra
            // 
            this.sortfra.AutoSize = true;
            this.sortfra.Checked = true;
            this.sortfra.CheckState = System.Windows.Forms.CheckState.Checked;
            this.sortfra.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sortfra.Location = new System.Drawing.Point(207, 693);
            this.sortfra.Name = "sortfra";
            this.sortfra.Size = new System.Drawing.Size(41, 17);
            this.sortfra.TabIndex = 69;
            this.sortfra.Text = "Fra";
            this.sortfra.UseVisualStyleBackColor = true;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(15, 713);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(115, 13);
            this.label30.TabIndex = 70;
            this.label30.Text = "Sorteret efter vægt";
            // 
            // vagtlisttil
            // 
            this.vagtlisttil.AutoSize = true;
            this.vagtlisttil.Cursor = System.Windows.Forms.Cursors.Hand;
            this.vagtlisttil.Location = new System.Drawing.Point(164, 712);
            this.vagtlisttil.Name = "vagtlisttil";
            this.vagtlisttil.Size = new System.Drawing.Size(37, 17);
            this.vagtlisttil.TabIndex = 71;
            this.vagtlisttil.Text = "Til";
            this.vagtlisttil.UseVisualStyleBackColor = true;
            // 
            // vagtlist
            // 
            this.vagtlist.AutoSize = true;
            this.vagtlist.Checked = true;
            this.vagtlist.CheckState = System.Windows.Forms.CheckState.Checked;
            this.vagtlist.Cursor = System.Windows.Forms.Cursors.Hand;
            this.vagtlist.Location = new System.Drawing.Point(207, 713);
            this.vagtlist.Name = "vagtlist";
            this.vagtlist.Size = new System.Drawing.Size(41, 17);
            this.vagtlist.TabIndex = 72;
            this.vagtlist.Text = "Fra";
            this.vagtlist.UseVisualStyleBackColor = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1231, 821);
            this.Controls.Add(this.vagtlist);
            this.Controls.Add(this.vagtlisttil);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.sortfra);
            this.Controls.Add(this.sorttil);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.checkfra);
            this.Controls.Add(this.checktil);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.radionavn);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.radiotype);
            this.Controls.Add(this.radiostyrke);
            this.Controls.Add(this.radiosurhed);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.radiopris);
            this.Controls.Add(this.radiovagt);
            this.Controls.Add(this.radiofave);
            this.Controls.Add(this.showgrid);
            this.Controls.Add(this.hidegrid);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lukke);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.kolonnenavn);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.txtIDupdate);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.display);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.sognulstil);
            this.Controls.Add(this.sognavn);
            this.Controls.Add(this.søg);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtupdatenavn);
            this.Controls.Add(this.clearslet);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtslet);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.slet);
            this.Controls.Add(this.update);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.Indset);
            this.Controls.Add(this.txtpris);
            this.Controls.Add(this.txttype);
            this.Controls.Add(this.txtstyrke);
            this.Controls.Add(this.txtsurhed);
            this.Controls.Add(this.txtvagt);
            this.Controls.Add(this.txtfave);
            this.Controls.Add(this.txtnavn);
            this.MaximumSize = new System.Drawing.Size(1265, 860);
            this.MinimumSize = new System.Drawing.Size(363, 860);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bolcher Desktop Controller ";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bolchertabelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSetBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtnavn;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox txtfave;
        private System.Windows.Forms.TextBox txtvagt;
        private System.Windows.Forms.TextBox txtsurhed;
        private System.Windows.Forms.TextBox txtstyrke;
        private System.Windows.Forms.TextBox txttype;
        private System.Windows.Forms.TextBox txtpris;
        private System.Windows.Forms.Button Indset;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.Button slet;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtslet;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button clearslet;
        private System.Windows.Forms.TextBox txtupdatenavn;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button søg;
        private System.Windows.Forms.TextBox sognavn;
        private System.Windows.Forms.Button sognulstil;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button display;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtIDupdate;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox kolonnenavn;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button lukke;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button hidegrid;
        private System.Windows.Forms.Button showgrid;
        private System.Windows.Forms.RadioButton radiofave;
        private System.Windows.Forms.RadioButton radiovagt;
        private System.Windows.Forms.RadioButton radiopris;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.RadioButton radiotype;
        private System.Windows.Forms.RadioButton radiostyrke;
        private System.Windows.Forms.RadioButton radiosurhed;
        private System.Windows.Forms.RadioButton radionavn;
        private databaseDataSet databaseDataSet;
        private System.Windows.Forms.BindingSource bolchertabelBindingSource;
        private databaseDataSetTableAdapters.bolchertabelTableAdapter bolchertabelTableAdapter;
        private System.Windows.Forms.BindingSource databaseDataSetBindingSource;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.CheckBox checktil;
        private System.Windows.Forms.CheckBox checkfra;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.CheckBox sorttil;
        private System.Windows.Forms.CheckBox sortfra;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.CheckBox vagtlisttil;
        private System.Windows.Forms.CheckBox vagtlist;
    }
}

